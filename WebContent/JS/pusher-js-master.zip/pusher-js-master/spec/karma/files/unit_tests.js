module.exports = [
  'spec/javascripts/helpers/mocks.js',
  'spec/javascripts/helpers/integration.js',
  'spec/javascripts/unit/**/*_spec.js'
];
