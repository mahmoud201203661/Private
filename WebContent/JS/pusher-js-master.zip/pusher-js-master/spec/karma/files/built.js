module.exports = [
  'target/pusher.min.js',

  'target/xhr.min.js',
  'target/xdr.min.js'
];
